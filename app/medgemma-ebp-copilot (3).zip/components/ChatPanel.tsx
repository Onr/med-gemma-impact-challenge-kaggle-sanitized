
import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { Message, Phase } from '../types';
import { PHASE_COLORS } from '../constants';

interface ChatPanelProps {
  messages: Message[];
  currentPhase: Phase;
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  draftInput: string;
  onDraftInputConsumed: () => void;
}

const ChatPanel: React.FC<ChatPanelProps> = ({ 
  messages, 
  currentPhase, 
  onSendMessage, 
  isLoading,
  draftInput,
  onDraftInputConsumed
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isListening, setIsListening] = useState(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (draftInput) {
        setInputText(prev => prev ? `${prev} ${draftInput}` : draftInput);
        onDraftInputConsumed();
    }
  }, [draftInput, onDraftInputConsumed]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (inputText.trim() && !isLoading) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  // Basic Speech Recognition (Chrome/Edge only)
  const toggleVoice = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(prev => prev ? `${prev} ${transcript}` : transcript);
      };

      recognition.start();
    } else {
      alert("Speech recognition not supported in this browser.");
    }
  };

  // Helper to render phase divider
  const renderPhaseDivider = (phase: Phase) => (
      <div className="flex items-center gap-4 py-4 opacity-70">
          <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent to-slate-600"></div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 border border-slate-600 rounded-full px-3 py-1 bg-slate-900">
             Entering {phase}
          </div>
          <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent to-slate-600"></div>
      </div>
  );

  // Helper to render extracted data visualizations inline
  const renderExtractedData = (data: any) => {
      if (!data) return null;
      
      const cardClass = "mt-3 bg-black/20 rounded-lg p-3 text-xs border border-white/10";
      const titleClass = "font-bold uppercase tracking-wider text-white/70 mb-2 border-b border-white/10 pb-1";

      switch (data.type) {
        case 'PICO_UPDATE':
            return (
                <div className={cardClass}>
                    <div className={titleClass}>Updated PICO Context</div>
                    <div className="grid grid-cols-2 gap-2">
                        <div><span className="text-sky-400 font-bold">P:</span> {data.data.patient || '-'}</div>
                        <div><span className="text-emerald-400 font-bold">I:</span> {data.data.intervention || '-'}</div>
                        <div><span className="text-amber-400 font-bold">C:</span> {data.data.comparison || '-'}</div>
                        <div><span className="text-rose-400 font-bold">O:</span> {data.data.outcome || '-'}</div>
                    </div>
                </div>
            );
        case 'REFERENCE_UPDATE':
            return (
                <div className={cardClass}>
                    <div className={titleClass}>Added References ({data.data.length})</div>
                    <ul className="space-y-2">
                        {data.data.map((ref: any, i: number) => (
                            <li key={i} className="flex gap-2">
                                <span className="bg-emerald-500/20 text-emerald-300 px-1 rounded h-fit">{ref.type}</span>
                                <div>
                                    <div className="font-semibold text-slate-200">{ref.title}</div>
                                    <div className="opacity-60">{ref.source} ({ref.year})</div>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            );
        case 'APPLY_UPDATE':
            return (
                <div className={cardClass}>
                     <div className={titleClass}>Clinical Actions ({data.data.length})</div>
                     <ul className="list-disc pl-4 space-y-1">
                        {data.data.map((item: any, i: number) => (
                            <li key={i}>
                                <span className="font-medium text-purple-300">{item.action}</span>
                            </li>
                        ))}
                     </ul>
                </div>
            );
        default:
            return null;
      }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border-l border-slate-800 shadow-2xl w-full relative z-20">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 bg-slate-900/95 backdrop-blur flex justify-between items-center">
         <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2 tracking-tight">
            <span className="material-symbols-outlined text-sky-500">medical_services</span>
            MedGemma
        </h2>
        <div className="text-xs text-slate-500 font-medium px-2 py-1 bg-slate-800 rounded border border-slate-700">
            {currentPhase} Phase
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2 scrollbar-hide bg-slate-900">
        {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-slate-600 text-center space-y-3 opacity-60">
                <div className="p-4 bg-slate-800 rounded-full">
                    <span className="material-symbols-outlined text-4xl">chat_bubble_outline</span>
                </div>
                <p className="text-sm font-medium">Start by describing your clinical case.</p>
            </div>
        )}
        
        {messages.map((msg, index) => {
          // Check previous message phase to determine divider
          const prevPhase = index > 0 ? messages[index - 1].phase : null;
          // Divider shows if current message starts a NEW phase compared to previous
          const showDivider = index > 0 && msg.phase && prevPhase && msg.phase !== prevPhase;
          const msgPhase = msg.phase || Phase.ASK; 

          return (
            <React.Fragment key={msg.id}>
              {showDivider && renderPhaseDivider(msgPhase)}
              <div className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} mb-3`}>
                <div
                  className={`max-w-[90%] rounded-2xl p-3.5 text-sm leading-relaxed shadow-md ${
                    msg.role === 'user'
                      ? 'bg-sky-600 text-white rounded-br-none'
                      : 'bg-slate-800 text-slate-200 rounded-bl-none border border-slate-700'
                  }`}
                  style={msg.role === 'model' ? { borderLeft: `3px solid ${PHASE_COLORS[msgPhase]}` } : {}}
                >
                  {msg.role === 'user' ? (
                    <div className="whitespace-pre-wrap">{msg.content}</div>
                  ) : (
                    <div>
                        <ReactMarkdown
                            components={{
                                p: ({node, ...props}) => <p className="mb-2 last:mb-0" {...props} />,
                                ul: ({node, ...props}) => <ul className="list-disc ml-4 mb-2 space-y-1" {...props} />,
                                ol: ({node, ...props}) => <ol className="list-decimal ml-4 mb-2 space-y-1" {...props} />,
                                li: ({node, ...props}) => <li className="pl-1" {...props} />,
                                strong: ({node, ...props}) => <strong className="font-semibold text-sky-300" {...props} />,
                                a: ({node, ...props}) => <a className="text-sky-400 hover:underline" target="_blank" {...props} />,
                                h1: ({node, ...props}) => <h1 className="text-lg font-bold mb-2" {...props} />,
                                h2: ({node, ...props}) => <h2 className="text-base font-bold mb-2 mt-3" {...props} />,
                                h3: ({node, ...props}) => <h3 className="text-sm font-bold mb-1 mt-2" {...props} />,
                                blockquote: ({node, ...props}) => <blockquote className="border-l-2 border-slate-600 pl-3 italic text-slate-400 my-2" {...props} />,
                            }}
                        >
                            {msg.content}
                        </ReactMarkdown>
                        {/* Inline Extracted Data Visualization */}
                        {msg.role === 'model' && msg.extractedData && renderExtractedData(msg.extractedData)}
                    </div>
                  )}
                </div>
              </div>
            </React.Fragment>
          );
        })}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-800 rounded-2xl p-4 rounded-bl-none flex gap-1.5 border border-slate-700">
              <div className="w-1.5 h-1.5 bg-sky-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
              <div className="w-1.5 h-1.5 bg-sky-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
              <div className="w-1.5 h-1.5 bg-sky-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 bg-slate-900 border-t border-slate-800">
        <form onSubmit={handleSubmit} className="flex items-end gap-2 relative">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSubmit();
                }
            }}
            placeholder={`Ask about ${currentPhase.toLowerCase()}...`}
            className="w-full bg-slate-800 text-white rounded-xl py-3.5 pl-4 pr-12 resize-none focus:outline-none focus:ring-1 focus:ring-sky-500 min-h-[52px] max-h-[120px] scrollbar-hide border border-slate-700 placeholder-slate-500 text-sm transition-all"
            rows={1}
          />
          <button
            type="button"
            onClick={toggleVoice}
            className={`absolute right-14 bottom-3 p-1.5 rounded-full transition-colors ${
              isListening ? 'bg-red-500/20 text-red-500 animate-pulse' : 'text-slate-400 hover:text-white'
            }`}
            title="Voice Input"
          >
            <span className="material-symbols-outlined text-lg">mic</span>
          </button>
          
          <button
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className="p-3 bg-sky-600 hover:bg-sky-500 disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-xl transition-all shadow-lg shadow-sky-900/20 flex-shrink-0"
          >
            <span className="material-symbols-outlined text-xl">send</span>
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatPanel;
