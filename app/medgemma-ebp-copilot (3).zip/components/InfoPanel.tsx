
import React from 'react';
import { AppState, Phase, Reference, AppraisalPoint, ApplyPoint, AssessPoint } from '../types';

interface InfoPanelProps {
  state: AppState;
  onChangePhase: (p: Phase) => void;
  onChipClick: (text: string) => void;
}

const InfoPanel: React.FC<InfoPanelProps> = ({ state, onChangePhase, onChipClick }) => {
  const { currentPhase, pico, references, appraisals, applyPoints, assessPoints } = state;

  const renderPicoChip = (label: string, value: string, colorClass: string) => (
    <div className="bg-slate-800 rounded-lg p-3 border border-slate-700 relative group hover:border-slate-500 transition-colors h-full">
      <div className={`text-[10px] uppercase tracking-wider font-bold mb-1 ${colorClass}`}>
        {label}
      </div>
      <div className="text-sm text-slate-200">
        {value || <span className="text-slate-600 italic">Not extracted yet...</span>}
      </div>
    </div>
  );

  const getVerdictColor = (verdict: AppraisalPoint['verdict']) => {
      switch(verdict) {
          case 'Positive': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
          case 'Negative': return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
          case 'Neutral': return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
          default: return 'bg-slate-700 text-slate-300';
      }
  };

  const formatTime = (ts?: number) => {
      if (!ts) return '';
      return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Common grid class for all phases
  const gridClass = "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4";

  return (
    <div className="bg-transparent flex flex-col h-full w-full">
      {/* Tabs */}
      <div className="flex border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm">
        {[Phase.ASK, Phase.ACQUIRE, Phase.APPRAISE, Phase.APPLY, Phase.ASSESS].map((p) => (
          <button
            key={p}
            onClick={() => onChangePhase(p)}
            className={`px-6 py-2.5 text-xs font-medium transition-colors border-b-2 whitespace-nowrap ${
              currentPhase === p
                ? 'text-white border-sky-500 bg-slate-800/50'
                : 'text-slate-500 border-transparent hover:text-slate-300 hover:bg-slate-800/30'
            }`}
          >
            {p}
          </button>
        ))}
      </div>

      <div className="p-4 md:p-6 overflow-y-auto flex-1">
        
        {/* ASK Content */}
        {currentPhase === Phase.ASK && (
          <div className="space-y-4 animate-fade-in h-full flex flex-col">
            <div className="flex justify-between items-center mb-2">
                 <h3 className="text-sm font-semibold text-sky-400 uppercase tracking-wider">Clinical Question (PICO)</h3>
                 <div className="flex items-center gap-3 w-64">
                    <div className="text-xs text-slate-400">Completeness: {pico.completeness}%</div>
                    <div className="h-1.5 flex-1 bg-slate-800 rounded-full overflow-hidden">
                        <div 
                        className="h-full bg-gradient-to-r from-blue-500 to-emerald-500 transition-all duration-700"
                        style={{ width: `${pico.completeness}%` }}
                        />
                    </div>
                 </div>
            </div>
            
            <div className={gridClass}>
              {renderPicoChip('Patient / Problem', pico.patient, 'text-blue-400')}
              {renderPicoChip('Intervention', pico.intervention, 'text-emerald-400')}
              {renderPicoChip('Comparison', pico.comparison, 'text-amber-400')}
              {renderPicoChip('Outcome', pico.outcome, 'text-rose-400')}
            </div>
          </div>
        )}

        {/* ACQUIRE Content */}
        {currentPhase === Phase.ACQUIRE && (
          <div className="space-y-4 animate-fade-in">
            <h3 className="text-sm font-semibold text-emerald-400 uppercase tracking-wider mb-2">Evidence Library</h3>
            {references.length === 0 ? (
                <div className="text-slate-500 text-sm italic text-center py-8 border border-dashed border-slate-700 rounded-xl bg-slate-800/20">
                    No references collected yet. Ask the Copilot to search for evidence.
                </div>
            ) : (
                <div className={gridClass}>
                    {references.map(ref => (
                        <div 
                            key={ref.id} 
                            onClick={() => onChipClick(`Re: Study "${ref.title}" (${ref.year}) - `)}
                            className="bg-slate-800 p-3 rounded-lg border border-slate-700 hover:bg-slate-750 hover:border-emerald-500/50 cursor-pointer transition-all group h-full flex flex-col"
                        >
                            <div className="flex justify-between items-start mb-2">
                                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-bold">{ref.type}</span>
                                <div className="text-[10px] text-slate-500 flex gap-2">
                                    <span>{ref.year}</span>
                                </div>
                            </div>
                            <div className="font-medium text-slate-200 text-sm mb-auto group-hover:text-emerald-300 transition-colors line-clamp-2">{ref.title}</div>
                            <div className="text-xs text-slate-400 mt-2">{ref.source}</div>
                        </div>
                    ))}
                </div>
            )}
          </div>
        )}

        {/* APPRAISE Content */}
        {currentPhase === Phase.APPRAISE && (
            <div className="space-y-4 animate-fade-in">
                <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider mb-2">Critical Appraisal</h3>
                {appraisals.length === 0 ? (
                    <div className="text-slate-500 text-sm italic text-center py-8 border border-dashed border-slate-700 rounded-xl bg-slate-800/20">
                        No appraisal points yet. Discuss specific studies to evaluate them.
                    </div>
                ) : (
                    <div className={gridClass}>
                        {appraisals.map((item) => (
                            <div 
                                key={item.id} 
                                onClick={() => onChipClick(`Re: Appraisal point "${item.title}" - `)}
                                className={`p-3 rounded-lg border ${getVerdictColor(item.verdict)} border-opacity-30 bg-opacity-10 cursor-pointer hover:bg-opacity-20 transition-all h-full flex flex-col`}
                            >
                                <div className="flex justify-between items-center mb-2">
                                    <span className="font-bold text-xs uppercase tracking-wide truncate pr-2">{item.title}</span>
                                    <div className="flex items-center gap-1 shrink-0">
                                        {item.verdict === 'Positive' && <span className="material-symbols-outlined text-sm">check_circle</span>}
                                        {item.verdict === 'Negative' && <span className="material-symbols-outlined text-sm">warning</span>}
                                        {item.verdict === 'Neutral' && <span className="material-symbols-outlined text-sm">remove_circle</span>}
                                    </div>
                                </div>
                                <div className="text-sm opacity-90 leading-tight">
                                    {item.description}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        )}

        {/* APPLY Content */}
        {currentPhase === Phase.APPLY && (
            <div className="space-y-4 animate-fade-in">
                <h3 className="text-sm font-semibold text-purple-400 uppercase tracking-wider mb-2">Clinical Actions</h3>
                {applyPoints.length === 0 ? (
                    <div className="text-slate-500 text-sm italic text-center py-8 border border-dashed border-slate-700 rounded-xl bg-slate-800/20">
                        No action items yet. Ask to synthesize evidence into a plan.
                    </div>
                ) : (
                    <div className={gridClass}>
                        {applyPoints.map((item) => (
                            <div 
                                key={item.id} 
                                onClick={() => onChipClick(`Re: Action "${item.action}" - `)}
                                className="bg-slate-800 p-3 rounded-lg border border-slate-700 hover:border-purple-500/50 cursor-pointer transition-all hover:bg-slate-750 h-full flex flex-col"
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <span className="text-[10px] bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded uppercase font-bold">Action</span>
                                </div>
                                <div className="font-medium text-slate-200 text-sm mb-2">{item.action}</div>
                                <div className="text-xs text-slate-400 italic mt-auto">"{item.rationale}"</div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        )}

        {/* ASSESS Content */}
        {currentPhase === Phase.ASSESS && (
            <div className="space-y-4 animate-fade-in">
                <h3 className="text-sm font-semibold text-rose-400 uppercase tracking-wider mb-2">Outcome Measures</h3>
                {assessPoints.length === 0 ? (
                    <div className="text-slate-500 text-sm italic text-center py-8 border border-dashed border-slate-700 rounded-xl bg-slate-800/20">
                        No outcome measures defined yet. Ask to define metrics for success.
                    </div>
                ) : (
                    <div className={gridClass}>
                        {assessPoints.map((item) => (
                            <div 
                                key={item.id} 
                                onClick={() => onChipClick(`Re: Metric "${item.metric}" - `)}
                                className="bg-slate-800 p-3 rounded-lg border border-slate-700 hover:border-rose-500/50 cursor-pointer transition-all hover:bg-slate-750 h-full flex flex-col"
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <span className="text-[10px] bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded uppercase font-bold">Metric</span>
                                </div>
                                <div className="font-medium text-slate-200 text-sm mb-2">{item.metric}</div>
                                <div className="flex justify-between text-xs text-slate-400 mt-auto border-t border-slate-700/50 pt-2">
                                    <span>Target: <span className="text-rose-200">{item.target}</span></span>
                                    <span>Freq: <span className="text-rose-200">{item.frequency}</span></span>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        )}

      </div>
    </div>
  );
};

export default InfoPanel;
