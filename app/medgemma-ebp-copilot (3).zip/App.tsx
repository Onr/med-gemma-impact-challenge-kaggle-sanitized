
import React, { useState } from 'react';
import { AppState, Message, Phase, Role } from './types';
import RadialProgress from './components/RadialProgress';
import ChatPanel from './components/ChatPanel';
import InfoPanel from './components/InfoPanel';
import SettingsModal from './components/SettingsModal';
import { sendMessageToGemini } from './services/geminiService';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    currentPhase: Phase.ASK,
    userRole: Role.PHYSICIAN,
    patientContext: '',
    pico: { patient: '', intervention: '', comparison: '', outcome: '', completeness: 0 },
    references: [],
    appraisals: [],
    applyPoints: [],
    assessPoints: [],
    messages: [
        {
            id: 'init',
            role: 'model',
            content: "Hello. I am MedGemma, your EBP Copilot. I can help you structure your clinical question using PICO framework. Please describe your patient case.",
            timestamp: Date.now(),
            phase: Phase.ASK
        }
    ],
    isLoading: false,
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [draftInput, setDraftInput] = useState<string>('');

  const handleSendMessage = async (text: string) => {
    // Optimistic UI Update
    const userMsg: Message = {
        id: Date.now().toString(),
        role: 'user',
        content: text,
        timestamp: Date.now(),
        phase: state.currentPhase
    };

    setState(prev => ({
        ...prev,
        messages: [...prev.messages, userMsg],
        isLoading: true
    }));

    // API Call
    const { text: aiResponseText, extractedData } = await sendMessageToGemini(
        [...state.messages, userMsg], // Pass history including new message
        text,
        state.userRole,
        state.currentPhase,
        state.patientContext
    );

    // Determine if phase changed
    let newPhase = state.currentPhase;
    if (extractedData && extractedData.type === 'PHASE_CHANGE') {
        const potentialPhase = extractedData.data as Phase;
        if (Object.values(Phase).includes(potentialPhase)) {
            newPhase = potentialPhase;
        }
    }

    const modelMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: aiResponseText,
        timestamp: Date.now(),
        extractedData,
        phase: newPhase // Associate message with the NEW phase if changed
    };

    setState(prev => {
        let newState = {
            ...prev,
            currentPhase: newPhase,
            messages: [...prev.messages, modelMsg],
            isLoading: false
        };

        // Handle State Updates from AI JSON
        if (extractedData) {
            const timestamp = Date.now();
            if (extractedData.type === 'PICO_UPDATE') {
                newState.pico = { ...prev.pico, ...extractedData.data };
            } else if (extractedData.type === 'REFERENCE_UPDATE') {
                const newRefs = extractedData.data.map((r: any, idx: number) => ({
                    ...r,
                    id: `ref-${timestamp}-${idx}`,
                    timestamp
                }));
                newState.references = [...prev.references, ...newRefs];
            } else if (extractedData.type === 'APPRAISAL_UPDATE') {
                 const newAppraisals = extractedData.data.map((a: any, idx: number) => ({
                    ...a,
                    id: `apr-${timestamp}-${idx}`,
                    timestamp
                 }));
                 newState.appraisals = [...prev.appraisals, ...newAppraisals];
            } else if (extractedData.type === 'APPLY_UPDATE') {
                const newPoints = extractedData.data.map((a: any, idx: number) => ({
                    ...a,
                    id: `apl-${timestamp}-${idx}`,
                    timestamp
                 }));
                 newState.applyPoints = [...prev.applyPoints, ...newPoints];
            } else if (extractedData.type === 'ASSESS_UPDATE') {
                const newPoints = extractedData.data.map((a: any, idx: number) => ({
                    ...a,
                    id: `ass-${timestamp}-${idx}`,
                    timestamp
                 }));
                 newState.assessPoints = [...prev.assessPoints, ...newPoints];
            }
        }
        
        return newState;
    });
  };

  const handlePhaseChange = (phase: Phase) => {
    setState(prev => ({ ...prev, currentPhase: phase }));
  };

  const handleSettingsSave = (role: Role, context: string) => {
      setState(prev => ({
          ...prev,
          userRole: role,
          patientContext: context
      }));
  };

  const handleChipClick = (text: string) => {
      setDraftInput(prev => prev ? `${prev} ${text}` : text);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-sans">
      
      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        currentRole={state.userRole}
        currentPatientContext={state.patientContext}
        onSave={handleSettingsSave}
      />

      {/* Main Content Area (Left of Chat) */}
      <div className="flex-1 flex flex-col relative min-w-0">
        
        {/* Background Decorative Gradient */}
        <div className="absolute inset-0 bg-slate-950 -z-20"></div>
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none opacity-40">
            <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-900/20 rounded-full blur-[100px]"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-900/20 rounded-full blur-[100px]"></div>
        </div>

        {/* Branding Header */}
        <div className="absolute top-6 left-6 z-30">
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span className="w-2 h-8 bg-sky-500 rounded-full"></span>
                MedGemma <span className="text-slate-500 font-light">EBP</span>
            </h1>
        </div>

        {/* Top Half: Radial Visualization */}
        <div className="flex-1 relative flex items-center justify-center min-h-0">
            <div className="scale-[0.7] md:scale-[0.75] lg:scale-[0.85] xl:scale-95 transition-transform">
                <RadialProgress 
                    currentPhase={state.currentPhase} 
                    onPhaseSelect={handlePhaseChange}
                    picoCompleteness={state.pico.completeness}
                    patientContext={state.patientContext}
                    userRole={state.userRole}
                    onCenterClick={() => setIsSettingsOpen(true)}
                />
            </div>
        </div>

        {/* Bottom Half: Info Panel */}
        <div className="h-[45vh] min-h-[300px] bg-slate-900/60 backdrop-blur-lg border-t border-slate-800 z-10 flex flex-col">
            <InfoPanel 
                state={state} 
                onChangePhase={handlePhaseChange} 
                onChipClick={handleChipClick}
            />
        </div>
      </div>

      {/* Right Area: Chat (Wider) */}
      <div className="w-[500px] lg:w-[600px] xl:w-[700px] h-full z-20 shadow-2xl shadow-black/80 flex-shrink-0 border-l border-slate-800">
        <ChatPanel 
            messages={state.messages}
            currentPhase={state.currentPhase}
            onSendMessage={handleSendMessage}
            isLoading={state.isLoading}
            draftInput={draftInput}
            onDraftInputConsumed={() => setDraftInput('')}
        />
      </div>

    </div>
  );
};

export default App;
