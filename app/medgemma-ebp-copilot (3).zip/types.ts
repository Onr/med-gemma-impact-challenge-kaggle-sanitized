export enum Phase {
  ASK = 'ASK',
  ACQUIRE = 'ACQUIRE',
  APPRAISE = 'APPRAISE',
  APPLY = 'APPLY',
  ASSESS = 'ASSESS'
}

export enum Role {
  PHYSICIAN = 'Physician',
  PT = 'Physical Therapist',
  OT = 'Occupational Therapist',
  NURSE = 'Nurse',
  PHARMACIST = 'Pharmacist'
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  phase?: Phase; // Track which phase this message belongs to
  extractedData?: any; 
}

export interface PicoData {
  patient: string;
  intervention: string;
  comparison: string;
  outcome: string;
  completeness: number; // 0-100
}

export interface Reference {
  id: string;
  title: string;
  source: string;
  year: string;
  type: string;
  relevance: 'High' | 'Medium' | 'Low';
  timestamp?: number;
}

export interface AppraisalPoint {
  id: string;
  title: string;
  description: string;
  verdict: 'Positive' | 'Negative' | 'Neutral';
  timestamp?: number;
}

export interface ApplyPoint {
  id: string;
  action: string;
  rationale: string;
  timestamp?: number;
}

export interface AssessPoint {
  id: string;
  metric: string;
  target: string;
  frequency: string;
  timestamp?: number;
}

export interface AppState {
  currentPhase: Phase;
  userRole: Role;
  patientContext: string;
  pico: PicoData;
  references: Reference[];
  appraisals: AppraisalPoint[];
  applyPoints: ApplyPoint[];
  assessPoints: AssessPoint[];
  messages: Message[];
  isLoading: boolean;
}
